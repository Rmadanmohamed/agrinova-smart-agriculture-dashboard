# AgriNova Report Folder

`definition.pbir` points to `../AgriNova.SemanticModel`. Open `AgriNova.pbip` or this `definition.pbir` in Power BI Desktop to load the model.

The visual build is specified in `../../docs/report_layout.md` and `../../docs/page_blueprint.csv`. The current environment cannot launch Power BI Desktop or Power BI Service, so visual placement must be completed after opening the project in Desktop.
